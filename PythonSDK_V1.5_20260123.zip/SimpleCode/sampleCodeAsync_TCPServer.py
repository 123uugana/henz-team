from datetime import datetime
from com.rfid.Reader import Reader
from com.rfid.enumeration.EReaderEnum import EReaderEnum
from com.rfid.enumeration.EReaderResult import EReaderResult
from com.rfid.interface.IAsynchronousMessage import IAsynchronousMessage
from com.rfid.models import ReaderInfo_Model
import time

class Text(IAsynchronousMessage):
    def __init__(self):
        self.connID = ""
    def main(self):
        log = Text()
        reader = Reader()
        if reader.openTcpServer("192.168.1.204", '9090', log):
            print("TCP server monitoring succeeded!")
        else:
            print("TCP server monitoring failed!")

        print("Waiting for 5s to listen for reader connections...")
        # Give the reader time to respond to the server, and you need to open a separate thread to listen when developing the program.
        time.sleep(5)  # (second)

        # <editor-fold desc="Single device">
        # Query reader information
        readerInfo = ReaderInfo_Model()
        reader.paramGet(EReaderEnum.RO_ReaderInformation, readerInfo)
        print("Reader SN: " + readerInfo.readerSN + " Reader Name: " + readerInfo.name + " Baseband Version: " + readerInfo.basebandVersion)

        # read tags
        rt = reader.inventory()
        if str(rt) == str(EReaderResult.RT_OK):
            print("Start reading tags OK")
        else:
            print("Start reading tags failed")

        time.sleep(5)  # (second)

        #   Stop reading
        reader.stop()
        reader.closeTcpServer()
        print("Stop reading")
        # </editor-fold>

        # <editor-fold desc="For multiple readers, you need to set the reader IP address separately">
        # Query reader information
        # readerInfo = ReaderInfo_Model()
        # reader.setConnID("192.168.1.116")
        # reader.paramGet(EReaderEnum.RO_ReaderInformation, readerInfo)
        # print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.116 ' + "Reader SN: " + readerInfo.readerSN + " Reader Name: " + readerInfo.name + " Baseband Version: " + readerInfo.basebandVersion)
        #
        # readerInfo2 = ReaderInfo_Model()
        # reader.setConnID("192.168.1.117")
        # reader.paramGet(EReaderEnum.RO_ReaderInformation, readerInfo2)
        # print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.117 ' + "Reader SN: " + readerInfo2.readerSN + " Reader Name: " + readerInfo2.name + " Baseband Version: " + readerInfo2.basebandVersion)

        # start reading tags
        # reader.setConnID("192.168.1.116")
        # rt = reader.inventory()
        # if str(rt) == str(EReaderResult.RT_OK):
        #     print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.116 ' + "Start reading tags OK")
        # else:
        #     print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.116 ' + "Start reading tags failed")
        #
        # reader.setConnID("192.168.1.117")
        # if str(rt) == str(EReaderResult.RT_OK):
        #     print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.117 ' + "Start reading tags OK")
        # else:
        #     print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.117 ' + "Start reading tags failed")

        #   Stop reading tags
        # reader.setConnID("192.168.1.116")
        # reader.stop()
        # print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.116 ' + "Stop reading")
        #
        # reader.setConnID("192.168.1.117")
        # reader.stop()
        # print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] 192.168.1.117 ' + "Stop reading")
        # </editor-fold>

        reader.closeTcpServer()
        print("Close the TCPServer connection.")

    def OutputTags(self, tag):
        try:
            print("EPC:" + tag._EPC + ",TID:" + tag._TID + ",_UserData:" + tag._UserData + ",_ReadTime:" + tag._ReadTime)
        except Exception as e:
            print("OutputTags callback failed.:" + e)

    def PortConnecting(self, newConnID):
        try:
            self.connID = newConnID
            print("TCPServer Connected Address:" + newConnID)
        except Exception as e:
            print("PortConnecting callback failed." + e)


if __name__ == '__main__':
    s = Text()
    s.main()